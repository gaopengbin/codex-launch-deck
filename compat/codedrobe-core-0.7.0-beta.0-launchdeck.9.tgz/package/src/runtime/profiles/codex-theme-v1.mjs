export const CODEX_THEME_V1_PROFILE = "codex-theme-v1";

function runtime({ theme, imageDataUrls = {}, imageUrls = {}, artDataUrl, artUrl = imageUrls.hero ?? artDataUrl }) {
  const CHROME_ID = "codedrobe-codex-skin-chrome";
  const COMPAT_STYLE_ID = "codedrobe-codex-skin-compat";
  const LEGACY_STYLE_ID = "codedrobe-codex-skin-style";
  const LEGACY_STATE_KEY = "__CODEDROBE_CODEX_SKIN_STATE__";
  const copy = {
    brandTitle: theme.displayName ?? "CodeDrobe",
    brandSubtitle: "",
    signature: "",
    tagline: "",
    projectPrefix: "",
    projectLabel: "",
    ribbon: "✦",
    ...(theme.copy ?? {}),
  };
  const cssString = (value) => JSON.stringify(String(value ?? ""));
  const ownedClasses = new Map();

  const addOwnedClass = (node, className) => {
    if (!node || node.classList.contains(className)) return;
    node.classList.add(className);
    const classes = ownedClasses.get(node) ?? new Set();
    classes.add(className);
    ownedClasses.set(node, classes);
  };

  const removeOwnedClasses = () => {
    for (const [node, classes] of ownedClasses) {
      for (const className of classes) node.classList.remove(className);
    }
    ownedClasses.clear();
  };

  const visibleShellMain = () => {
    const candidates = document.querySelectorAll("main.main-surface, #root main, main");
    let winner = null;
    let winnerArea = 0;
    for (const node of candidates) {
      const rect = node.getBoundingClientRect();
      const hiddenAncestor = node.closest('[aria-hidden="true"], [hidden], [inert]');
      let visible = !hiddenAncestor && rect.width > 0 && rect.height > 0 && node.getClientRects().length > 0;
      for (let current = node; visible && current; current = current.parentElement) {
        const style = getComputedStyle(current);
        visible = style.display !== "none" && style.visibility !== "hidden" &&
          style.contentVisibility !== "hidden" && Number(style.opacity) !== 0;
      }
      const area = visible ? rect.width * rect.height : 0;
      if (area > winnerArea) {
        winner = node;
        winnerArea = area;
      }
    }
    return winner;
  };

  const composerSurface = () => {
    const legacy = document.querySelector(".composer-surface-chrome");
    if (legacy) return legacy;
    const editor = document.querySelector(
      '.thread-scroll-container [role="textbox"][contenteditable="true"], .thread-scroll-container .ProseMirror',
    );
    if (!editor) return null;
    const boundary = editor.closest(".sticky.bottom-0") || editor.closest(".thread-scroll-container");
    const editorBox = editor.getBoundingClientRect();
    for (let node = editor.parentElement; node && node !== boundary; node = node.parentElement) {
      const box = node.getBoundingClientRect();
      const style = getComputedStyle(node);
      const radius = Number.parseFloat(style.borderTopLeftRadius) || 0;
      const painted = style.backgroundColor !== "rgba(0, 0, 0, 0)" || style.boxShadow !== "none";
      if (box.width >= editorBox.width && box.height >= editorBox.height && radius >= 12 && painted) {
        return node;
      }
    }
    return null;
  };

  const stopLegacyRuntime = () => {
    window.__CODEDROBE_CODEX_SKIN_DISABLED__ = true;
    const legacyState = window[LEGACY_STATE_KEY];
    try { legacyState?.cleanup?.(); } catch { /* Fall through to static cleanup. */ }
    legacyState?.observer?.disconnect?.();
    if (legacyState?.timer) clearInterval(legacyState.timer);
    if (legacyState?.scheduler?.timeout) clearTimeout(legacyState.scheduler.timeout);
    if (legacyState?.artUrl) globalThis.URL?.revokeObjectURL?.(legacyState.artUrl);
    document.getElementById(LEGACY_STYLE_ID)?.remove();
    delete window[LEGACY_STATE_KEY];
  };

  stopLegacyRuntime();

  const updateChromeCopy = (chrome) => {
    chrome.querySelector(".dream-brand-title").textContent = String(copy.brandTitle ?? "");
    chrome.querySelector(".dream-brand-subtitle").textContent = String(copy.brandSubtitle ?? "");
    chrome.querySelector(".dream-signature").textContent = String(copy.signature ?? "");
    chrome.querySelector(".dream-ribbon-emoji").textContent = String(copy.ribbon ?? "");
  };

  const ensureCompatibilityStyle = () => {
    let style = document.getElementById(COMPAT_STYLE_ID);
    if (!style) {
      style = document.createElement("style");
      style.id = COMPAT_STYLE_ID;
      (document.head || document.documentElement).appendChild(style);
    }
    style.textContent = `
      html.codedrobe-codex-skin .dream-home.codedrobe-modern-home.codedrobe-art-fallback {
        position: relative !important;
        isolation: isolate;
        min-height: 100% !important;
        background-image:
          linear-gradient(90deg,
            color-mix(in srgb, var(--color-token-main-surface-primary) 92%, transparent) 0%,
            color-mix(in srgb, var(--color-token-main-surface-primary) 72%, transparent) 38%,
            color-mix(in srgb, var(--color-token-main-surface-primary) 18%, transparent) 68%,
            transparent 100%),
          var(--dream-art) !important;
        background-position: center, right center !important;
        background-repeat: no-repeat, no-repeat !important;
        background-size: 100% 100%, cover !important;
      }
      html.codedrobe-codex-skin #root main.main-surface.codedrobe-conversation-theme.codedrobe-art-fallback {
        background-image:
          linear-gradient(90deg,
            color-mix(in srgb, var(--color-token-main-surface-primary) 88%, transparent) 0%,
            color-mix(in srgb, var(--color-token-main-surface-primary) 72%, transparent) 40%,
            color-mix(in srgb, var(--color-token-main-surface-primary) 40%, transparent) 70%,
            color-mix(in srgb, var(--color-token-main-surface-primary) 22%, transparent) 100%),
          var(--dream-art) !important;
        background-position: center, right center !important;
        background-repeat: no-repeat, no-repeat !important;
        background-size: 100% 100%, cover !important;
      }
    `;
  };

  const ensure = () => {
    const root = document.documentElement;
    if (!root) return false;
    root.classList.add("codedrobe-codex-skin");
    root.dataset.codexSkinTheme = theme.id;
    if (artUrl) root.style.setProperty("--dream-art", `url("${artUrl}")`);
    else root.style.removeProperty("--dream-art");
    root.style.setProperty("--dream-tagline", cssString(copy.tagline));
    root.style.setProperty("--dream-project-prefix", cssString(copy.projectPrefix));
    root.style.setProperty("--dream-project-label", cssString(copy.projectLabel));

    const shellMain = visibleShellMain();
    const legacyHomeSignal = document.querySelector('[role="main"]:has([data-testid="home-icon"])');
    const modernHomeSignal = document.querySelector('[data-feature="game-source"], .group\\/home-suggestions, .group\\/project-selector');
    const modernHome = modernHomeSignal?.closest('[role="main"]');
    const legacyHome = modernHome ? null : legacyHomeSignal;
    const home = legacyHome || modernHome;
    for (const candidate of document.querySelectorAll('.dream-home')) {
      if (candidate !== home) candidate.classList.remove("dream-home");
    }
    for (const candidate of document.querySelectorAll('.codedrobe-legacy-home, .codedrobe-modern-home')) {
      if (candidate !== home) candidate.classList.remove("codedrobe-legacy-home", "codedrobe-modern-home");
    }
    if (home) home.classList.add("dream-home");
    legacyHome?.classList.add("codedrobe-legacy-home");
    modernHome?.classList.add("codedrobe-modern-home");
    if (!shellMain || !document.body) return true;

    ensureCompatibilityStyle();
    addOwnedClass(shellMain, "main-surface");
    addOwnedClass(shellMain.querySelector(":scope > header"), "app-header-tint");
    const composer = composerSurface();
    addOwnedClass(composer, "composer-surface-chrome");
    const currentArtUrls = [...new Set([artUrl, ...Object.values(imageUrls)].filter(Boolean))];
    const paintsCurrentArt = (node) => Boolean(currentArtUrls.length && node && [null, "::before", "::after"].some((pseudo) => {
      // Do not let the compatibility fallback satisfy its own detection on the next pass.
      if (pseudo === null && node.classList.contains("codedrobe-art-fallback")) return false;
      const backgroundImage = getComputedStyle(node, pseudo).backgroundImage;
      return backgroundImage && backgroundImage !== "none" && currentArtUrls.some((url) => backgroundImage.includes(url));
    }));
    const needsArtFallback = Boolean(artUrl && ![shellMain, home].some(paintsCurrentArt));
    shellMain.classList.toggle("codedrobe-art-fallback", needsArtFallback);
    home?.classList.toggle("codedrobe-art-fallback", needsArtFallback);
    shellMain.classList.toggle("dream-home-shell", Boolean(home));
    const conversation = !home && shellMain.querySelector(".thread-scroll-container") && composer;
    shellMain.classList.toggle("codedrobe-conversation-theme", Boolean(conversation));
    let chrome = document.getElementById(CHROME_ID);
    if (!chrome || chrome.parentElement !== document.body || !chrome.querySelector(".dream-brand-title")) {
      chrome?.remove();
      chrome = document.createElement("div");
      chrome.id = CHROME_ID;
      chrome.setAttribute("aria-hidden", "true");
      chrome.innerHTML = `
        <div class="dream-brand"><span class="dream-note">♫</span><span><b class="dream-brand-title"></b><small class="dream-brand-subtitle"></small></span></div>
        <div class="dream-signature"></div>
        <div class="dream-sparkles"><i></i><i></i><i></i><i></i><i></i><i></i></div>
        <div class="dream-ribbon"><span>♡</span><b class="dream-ribbon-emoji"></b><span>✦</span></div>
        <div class="dream-polaroid"></div>`;
      document.body.appendChild(chrome);
    }
    updateChromeCopy(chrome);
    const shellBox = shellMain.getBoundingClientRect();
    chrome.style.left = `${Math.round(shellBox.left)}px`;
    chrome.style.top = `${Math.round(shellBox.top)}px`;
    chrome.style.width = `${Math.round(shellBox.width)}px`;
    chrome.style.height = `${Math.round(shellBox.height)}px`;
    chrome.classList.toggle("dream-home-shell", Boolean(home));
    return true;
  };

  const cleanup = () => {
    const root = document.documentElement;
    root?.classList.remove("codedrobe-codex-skin");
    if (root) delete root.dataset.codexSkinTheme;
    root?.style.removeProperty("--dream-art");
    root?.style.removeProperty("--dream-tagline");
    root?.style.removeProperty("--dream-project-prefix");
    root?.style.removeProperty("--dream-project-label");
    document.querySelectorAll(".dream-home").forEach((node) => node.classList.remove("dream-home"));
    document.querySelectorAll(".dream-home-shell").forEach((node) => node.classList.remove("dream-home-shell"));
    document.querySelectorAll(".codedrobe-conversation-theme").forEach((node) => node.classList.remove("codedrobe-conversation-theme"));
    document.querySelectorAll(".codedrobe-art-fallback").forEach((node) => node.classList.remove("codedrobe-art-fallback"));
    document.querySelectorAll(".codedrobe-legacy-home, .codedrobe-modern-home").forEach((node) => {
      node.classList.remove("codedrobe-legacy-home", "codedrobe-modern-home");
    });
    removeOwnedClasses();
    document.getElementById(COMPAT_STYLE_ID)?.remove();
    document.getElementById(CHROME_ID)?.remove();
  };

  const verify = () => {
    const root = document.documentElement;
    const chrome = document.getElementById(CHROME_ID);
    const nativeHome = document.querySelector('[role="main"]:has([data-testid="home-icon"])') ||
      document.querySelector('[data-feature="game-source"], .group\\/home-suggestions, .group\\/project-selector')?.closest('[role="main"]');
    const markedHome = document.querySelector('.dream-home');
    const missing = [];
    if (!root?.classList.contains("codedrobe-codex-skin")) {
      missing.push({ name: "legacy-root-class", selectors: ["html.codedrobe-codex-skin"] });
    }
    if (!chrome) missing.push({ name: "legacy-chrome", selectors: ["#codedrobe-codex-skin-chrome"] });
    if (chrome && getComputedStyle(chrome).pointerEvents !== "none") {
      missing.push({ name: "noninteractive-chrome", selectors: ["#codedrobe-codex-skin-chrome { pointer-events: none }"] });
    }
    if (artDataUrl && !root?.style.getPropertyValue("--dream-art")) {
      missing.push({ name: "legacy-art-variable", selectors: ["--dream-art"] });
    }
    if (nativeHome && markedHome !== nativeHome) {
      missing.push({ name: "legacy-home-marker", selectors: ['.dream-home'] });
    }
    return {
      id: "codex-theme-v1",
      pass: missing.length === 0,
      missing,
      rootClassPresent: Boolean(root?.classList.contains("codedrobe-codex-skin")),
      chromePresent: Boolean(chrome),
      homeContextActive: Boolean(nativeHome),
      homeMarked: !nativeHome || markedHome === nativeHome,
    };
  };

  return { ensure, cleanup, verify };
}

function cleanup() {
  window.__CODEDROBE_CODEX_SKIN_DISABLED__ = true;
  const legacyState = window.__CODEDROBE_CODEX_SKIN_STATE__;
  try { legacyState?.cleanup?.(); } catch { /* Fall through to static cleanup. */ }
  legacyState?.observer?.disconnect?.();
  if (legacyState?.timer) clearInterval(legacyState.timer);
  if (legacyState?.scheduler?.timeout) clearTimeout(legacyState.scheduler.timeout);
  if (legacyState?.artUrl) globalThis.URL?.revokeObjectURL?.(legacyState.artUrl);
  delete window.__CODEDROBE_CODEX_SKIN_STATE__;
  const root = document.documentElement;
  root?.classList.remove("codedrobe-codex-skin");
  if (root) delete root.dataset.codexSkinTheme;
  root?.style.removeProperty("--dream-art");
  root?.style.removeProperty("--dream-tagline");
  root?.style.removeProperty("--dream-project-prefix");
  root?.style.removeProperty("--dream-project-label");
  document.querySelectorAll(".dream-home").forEach((node) => node.classList.remove("dream-home"));
  document.querySelectorAll(".dream-home-shell").forEach((node) => node.classList.remove("dream-home-shell"));
  document.querySelectorAll(".codedrobe-conversation-theme").forEach((node) => node.classList.remove("codedrobe-conversation-theme"));
  document.querySelectorAll(".codedrobe-art-fallback").forEach((node) => node.classList.remove("codedrobe-art-fallback"));
  document.querySelectorAll(".codedrobe-legacy-home, .codedrobe-modern-home").forEach((node) => {
    node.classList.remove("codedrobe-legacy-home", "codedrobe-modern-home");
  });
  document.getElementById("codedrobe-codex-skin-style")?.remove();
  document.getElementById("codedrobe-codex-skin-compat")?.remove();
  document.getElementById("codedrobe-codex-skin-chrome")?.remove();
}

export default {
  id: CODEX_THEME_V1_PROFILE,
  runtime,
  cleanup,
};
