export const VERSION = "0.7.0-beta.0-launchdeck.2";
